<?php
$conn = mysqli_connect("localhost", "root", "", "responsi_0212");

$id_event = $_POST['id_event'];
$nama_pembeli = $_POST['nama_pembeli'];
$email_pembeli = $_POST['email_pembeli'];
$total_tiket = $_POST['total_tiket'];

$result = mysqli_query($conn, "SELECT kuota FROM events WHERE id = $id_event");
$data = mysqli_fetch_assoc($result);
$kuota = $data['kuota'];

if($kuota >= $total_tiket) {
    mysqli_query($conn, "UPDATE events SET kuota = kuota - $total_tiket WHERE id = $id_event");

    $kode_tiket = "TIX-" . rand(1000, 9999);

    mysqli_query($conn, "INSERT INTO pembelian (event_id, nama_pembeli, email_pembeli, kode_tiket, total_tiket)
                         VALUES ($id_event, '$nama_pembeli', '$email_pembeli', '$kode_tiket', $total_tiket)");

    echo "<h2>Pembelian Berhasil!</h2>";
    echo "<p>Kode Tiket Anda: <b>$kode_tiket</b></p>";
    echo "<a href='index.php'>Kembali ke Beranda</a>";
} else {
    echo "<h2>Maaf, tiket event ini sudah habis!</h2>";
    echo "<a href='index.php'>Kembali ke Beranda</a>";
}
?>