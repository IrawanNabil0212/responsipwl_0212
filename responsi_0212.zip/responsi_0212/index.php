<?php
$conn = mysqli_connect("localhost", "root", "", "responsi_0212");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
$result = mysqli_query($conn, "SELECT * FROM events");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Event</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 40px;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        table {
            border-collapse: collapse;
            width: 70%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }
        th {
            background: #007bff;
            color: white;
        }
        tr:hover {
            background: #f1f1f1;
        }
        a button {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .beli {
            background-color: #28a745;
            color: white;
        }
        .habis {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>

<h1>Daftar Event Tersedia</h1>

<table>
    <tr>
        <th>Nama Event</th>
        <th>Harga</th>
        <th>Kuota</th>
        <th>Aksi</th>
    </tr>

    <?php while($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['nama_event']; ?></td>
            <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
            <td><?= $row['kuota']; ?></td>
            <td>
                <?php if($row['kuota'] > 0) { ?>
                    <a href="beli.php?id_event=<?= $row['id']; ?>">
                        <button class="beli">Beli Tiket</button>
                    </a>
                <?php } else { ?>
                    <button class="habis" disabled>Tiket Habis</button>
                <?php } ?>
            </td>
        </tr>
    <?php } ?>

</table>

</body>
</html>