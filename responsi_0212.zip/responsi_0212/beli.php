<?php
$conn = mysqli_connect("localhost", "root", "", "responsi_0212");
$id_event = $_GET['id_event'];

$result = mysqli_query($conn, "SELECT * FROM events WHERE id = $id_event");
$event = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Beli Tiket</title>
  <style>
    body { font-family: Arial; margin: 40px; background: #eef; }
    form { background: white; padding: 20px; border-radius: 10px; width: 400px; }
    input { width: 100%; padding: 8px; margin: 8px 0; }
    button { background: green; color: white; border: none; padding: 10px; border-radius: 5px; }
  </style>
</head>
<body>
  <h2>Beli Tiket: <?= $event['nama_event']; ?></h2>
  <form method="POST" action="proses.php">
    <input type="hidden" name="id_event" value="<?= $event['id']; ?>">
    <label>Nama Lengkap:</label>
    <input type="text" name="nama_pembeli" required>
    
    <label>Email:</label>
    <input type="email" name="email_pembeli" required>
    
    <label>Total Tiket:</label>
    <input type="number" name="total_tiket" min="1" max="<?= $event['kuota']; ?>" required>
    
    <button type="submit">Kirim</button>
  </form>
</body>
</html>